package com.mygdx.zombieland.effects;

public interface Effect {

}
