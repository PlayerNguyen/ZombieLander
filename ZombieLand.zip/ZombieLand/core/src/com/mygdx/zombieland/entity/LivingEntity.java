package com.mygdx.zombieland.entity;

public interface LivingEntity extends Entity, Damageable {

}
