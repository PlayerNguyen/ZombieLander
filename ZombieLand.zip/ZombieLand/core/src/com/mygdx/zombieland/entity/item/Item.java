package com.mygdx.zombieland.entity.item;

import com.mygdx.zombieland.entity.Damageable;
import com.mygdx.zombieland.entity.Entity;

public interface Item extends Entity, Damageable {
}
