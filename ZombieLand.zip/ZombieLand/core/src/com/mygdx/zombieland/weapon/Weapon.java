package com.mygdx.zombieland.weapon;

public interface Weapon {

    float getDamage();

    void setDamage(float damage);

    float getKnockbackPower();

    void setKnockbackPower(float knockbackPower);

}
