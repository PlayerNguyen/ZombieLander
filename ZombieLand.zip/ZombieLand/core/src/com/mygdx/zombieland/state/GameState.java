package com.mygdx.zombieland.state;

public enum GameState {
    STARTING,
    PAUSING,
    PLAYING,
    ENDING

}
