# 🧟‍♂ ️Zombieland 🧟‍♂️

<p align="center"> 
   <img src ="https://user-images.githubusercontent.com/99407775/171654918-fd8e0b41-6241-4eb3-a25e-f7c803d1729f.png" width="150" height="150"/>
</p>



---

<p align="center"> 
 <img src ="https://user-images.githubusercontent.com/99407775/171653002-d47fd9ff-e0d4-4bc9-ab03-ce539587e035.png" />
 <br>
 <br>
 <b> "IT HAD TO BE A F***NG CLOWN!" </b>
</p>

<p align="center"> 
    <a href="https://github.com/PlayerNguyen/ZombieLand"><img src ="https://img.shields.io/github/issues/PlayerNguyen/ZombieLand?logo=Github" /></a>
    <a href="https://github.com/PlayerNguyen/ZombieLand"><img src ="https://img.shields.io/github/repo-size/PlayerNguyen/ZombieLand?logo=Github" /></a>
    <a href="https://github.com/PlayerNguyen/ZombieLand"><img src ="https://img.shields.io/github/contributors/PlayerNguyen/ZombieLand?logo=Github" /></a>
    <a href="https://github.com/PlayerNguyen/ZombieLand"><img src ="https://img.shields.io/github/commit-activity/w/PlayerNguyen/ZombieLand?logo=Github" /></a>
    <a href="https://github.com/PlayerNguyen/ZombieLand"><img src ="https://img.shields.io/badge/license-GPL--3.0-orange"></a>
    <br>
    <br>
Casual 2D-action game developed by Phour Team only available on PC.💻💻💻💻💻💻
</p>

---

## 📋 Table of Contents

* [About](#about)
* [Technologies](#technologies)
* [Setup](#setup)
* [Features](#features)
* [Project Status](#project-status)
* [Acknowledgements](#acknowledgements)

---

## About

### 📽 Game Trailer:

[![Watch video](https://img.youtube.com/vi/T-D1KVIuvjA/maxresdefault.jpg)](https://youtu.be/yWlJtO_M3vU)

### 📌 General Information

- __Game name:__ **Zombieland**

- __Category:__ **2D, Action, Shooting, Single player**

- __Lore:__
  _Our main character is Mr.Man, after a long day's work, he had slept on his work chair and when he woke up, he was already trapped in a 2D world, sitting on a rolling chair, incapable of moving due to its satisfaction. However, he is not alone in this world. Zombies are finding their way to approach and eat Mr.Man's ! Gifted by the 2D god (or goddess?), Mr.Man now has equipped a gun, try to live as long as you could._
<p align="center"> 
<img src= "https://user-images.githubusercontent.com/99407775/170820314-0b577ff7-70db-40a0-a3af-5dcc87aef667.gif" />
</p>

### 🎮 Rule:
- Use your mouse to rotate Mr.Man in the direction as you wish. Click left mouse to shoot.
- Zombies will get more crowded, stronger and closer to Mr.Man as you play. Kill them and keep Mr.Man safe.

<p align="center"> 
<img src = "https://user-images.githubusercontent.com/99407775/170820239-97022f96-d1de-4ee1-a844-7a60caad3ed8.gif" />
</p>

### 🏆 Our Motivation:
_Our main motivation by choosing this game is to hope that we could finalize our first game project and extends our knowledge while learning through trial and error coding. We claimed that Zombieland is not a rip-off of any other shooting game. Due to the lack of human resource and time we had, we tried our best to improvise the basic, easy-to-make-and-learn game. However, we still applied the game with our own features to make it challenging and entertaining, though keep it simple enough. Beside of that, this is a great chance for us to know how to team-work and lay the foundation for our future, regardless of any risks and circumstances, step by step from junior developer, grinding and become senior leadership someday. Moreover, Zombieland is a very popular phrase, a catchy name of a funny film about zombie apocalypse, so that you can infer a joyful asmosphere and easily understand what you will deal with while playing the game. Our final purpose is to let you play a fast-to-play-and-learn game, but still effectively funny and amused._

<p align="center">
<img src = "https://user-images.githubusercontent.com/99407775/169956417-39f9e4bf-89b7-4cb3-ba6f-66bb85fd49b3.jpg" width="420" height="300"/>
</p>

### 👨‍👦‍👦 Us

#### Team Name: 
 - **Phour Team**

#### Team Leader: 
- **Nguyen Huynh Nguyen** - ITITIU20261

| No  | Name                          | ID          | Main Contributes                                                                       | Contacts                                                                                                                                |
|-----|-------------------------------|-------------|----------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| 1   | **Nguyen Huynh Nguyen** 👨‍💻 | ITITIU20261 | Game Developer, Github repository host, Debug & fixing code, Tasks distributor.        | [Github](https://github.com/PlayerNguyen) [Facebook](https://www.facebook.com/Okura.Nguyen) [Email](mailto:nhnguyen.forwork@gmail.com)  |
| 2   | **Tran Tuan Nghiep** 👨‍🎨    | ITITIU20259 | Game artist, Idea contributor, Quality Checker, Tasks Tracker.                         | [Github](https://github.com/TuanNghiep) [Facebook](https://www.facebook.com/nghiep.tuan.58) [Email](mailto:nghieptrantuan@gmail.com)    |
| 3   | **Vo Trung Duong**✍           | ITITIU20193 | Game designer, Script Writer, Thoughts & Ideas Gatherer, Game Sounds & Music composer. | [Github](https://github.com/Callmeserpent) [Facebook](https://www.facebook.com/callmeserpent) [Email](mailto:voduong.hcmiu@gmail.com) |

<p align="center">
<img src= "https://user-images.githubusercontent.com/99407775/169956795-c0385c89-680b-4c5b-b347-caa156600829.jpg" width="180" height="410"/> 
<img src= "https://user-images.githubusercontent.com/99407775/169956846-9995cc3d-dc69-4b52-b792-9e0ddcacc683.jpg" width="180" height="410"/> 
<img src="https://user-images.githubusercontent.com/99407775/169956928-c4f8def2-fb22-422d-87e7-a7f43fedf070.jpg" width="180" height="410"/>
</p>

---

## Technologies

Project is created with:
- ![java_24x24](https://user-images.githubusercontent.com/99407775/169029133-7f054149-020d-4853-91dd-942b9d4045c0.png) Java Language.
- [Oracle JDK 17](https://www.oracle.com/java/technologies/javase/jdk17-archive-downloads.html).
- [libGDX](https://libgdx.com/) ![libGDX ver](https://img.shields.io/badge/version-1.10.0.-yellowgreen).
- [IntelliJ IDEA](https://www.jetbrains.com/idea/download/#section=windows) ![Intellij ver](https://img.shields.io/badge/version-2021.3.3-ff69b4).

## Setup
 - To run this project, [IntelliJ IDEA](https://www.jetbrains.com/idea/download/#section=windows) is required. 
 - Install the game by: 
   - Go to our [GitHub repository](https://github.com/PlayerNguyen/ZombieLand), click ``Code``, copy the ``HTTPS link``, or you can copy this URL link: https://github.com/PlayerNguyen/ZombieLand.git
   - Go back to your opened Intellij IDEA, click ``Git`` on menu bar, choose ``Clone...``.
   - Paste the URL link you've just copied and start to clone.

### 🔑 Launch
After opening project, find and open package `desktop`. Access package `src`, open and run file `DesktopLauncher`.

### ⚖️ License
This project is licensed under the ```GNU GPL ver.3```.
We would recommend that you read our [license](https://github.com/PlayerNguyen/ZombieLand/blob/master/LICENSE) to avoid copyrighted issues.

### ⚙ Architecture

<p align="center">
<img src= "https://raw.githubusercontent.com/PlayerNguyen/ZombieLand/master/diagrams/MainUMLDiagram.png"/> 
</p>

---

## Features
- Playable, short rule = long fun game to play in your free time.
- Relaxing background music to chill. 

https://user-images.githubusercontent.com/99407775/171133526-ce379963-b629-4db3-bbdb-60cffd1d0b5b.mov

- Funny characters, nice pixel art that suits every age.

 <img src = "https://user-images.githubusercontent.com/99407775/170941400-afa08aaf-6251-4f9b-9b5b-4ed1187dd430.png" width="200" height="200" /> <img src = "https://user-images.githubusercontent.com/99407775/170941690-a4545a61-936b-4770-afa4-53169bfe14bd.png" width="140" height="140"/>

Please [read more](https://github.com/PlayerNguyen/ZombieLand/blob/master/FEATURES.md) for details. 

---

## Project Status

Project is [**finished**](https://github.com/PlayerNguyen/ZombieLand/blob/master/TIMELINE.md).
🤔

### Challenging

Our team used to have 4 members, as well as we had planned to 
make a game based on **Slither.io**. We started very early. However, 
in the middle of our schedule, due to accident we now only have 3 members - 
which means we are lacking human resource. Finally, we chose to make a new 
project, with new ideas and features that conclude an easily make-able game.

---

## Acknowledgements
- 💡 This project was inspired by [**Shooter Heroes**](https://play.google.com/store/apps/details?id=com.LeventYavuzCompany.TheBeastGame&hl=en_US&gl=US) from 🎲**Levent Yavuz Company**🎲 and movie named [**Zombieland**](https://en.wikipedia.org/wiki/Zombieland) by 🎞**Ruben Fleischer**🎞.
- 👑 This readme file was base on these tutorials:
  - [Rita Łyczywek's tutorial](https://bulldogjob.com/news/449-how-to-write-a-good-readme-for-your-github-project).
  - [Hillary Nyakundi's tutorial](https://www.freecodecamp.org/news/how-to-write-a-good-readme-file/)
  - [Sana Ebadi's video](https://www.youtube.com/watch?v=vB_Z3JjkVwU)
- Many thanks to our mentor [**Tom Huynh**](mailto:tomhuynhsg@gmail.com) for guiding us.🤗

<p align="center">
  <img src = "https://user-images.githubusercontent.com/99407775/170937792-ab09dbb9-83b9-4a41-b462-f2f5cb5a541d.gif" width="350" height="360"/>
</p>
